p=(3.18-2.16)./0.002+1;
f=zeros(p,1);p1=1;
for gama=2.16:0.002:3.18
Lya1=[];Lya2=[];Lya3=[];
V=eye(3);
S=V;b1=0; 
a=0.4;c=0.2;b=4.0;
h=0.01;
x(1)=0.1;y(1)=0;z(1)=0;n=0;
while z<=200
n=n+1;
k1=h*y(n);
m1=h*(-sin(x(n))-a*y(n)+b*cos(gama*z(n)).*sin(x(n))+c);
k2=h*(y(n)+m1/2);
m2=h*(-sin(x(n)+k1/2)-a*(y(n)+m1/2)+b*cos(gama*(z(n)+h/2)).*sin(x(n)+k1/2)+c);
k3=h*(y(n)+m2/2);
m3=h*(-sin(x(n)+k2/2)-a*(y(n)+m2/2)+b*cos(gama*(z(n)+h/2)).*sin(x(n)+k2/2)+c);
k4=h*(y(n)+m3);
m4=h*(-sin(x(n)+k3)-a*(y(n)+m3)+b*cos(gama*(z(n)+h)).*sin(x(n)+k3)+c);
x(n+1)=x(n)+(k1+2*k2+2*k3+k4)/6;
y(n+1)=y(n)+(m1+2*m2+2*m3+m4)/6;
z(n+1)=n*h;
J = [0 1 0;
b*cos(gama*z(n+1))*cos(x(n+1))-cos(x(n+1)) -a -b*gama*sin(gama*z(n+1))*sin(x(n+1));
0 0 0];
J=eye(3)+h*J;
B=J*V*S;
[V,S,U]=svd(B);
a_max=max(diag(S));
S=(1/a_max)*S;
b1=b1+log(a_max);
Lyapunov1=(log(diag(S))+b1)/(n*h);
end
%disp([Lyapunov1(1,:)]');
disp([Lyapunov1]');
K=0;
for i=1:3
    if Lyapunov1(i,1)>0
        K=K+Lyapunov1(i,1);
    end
end
f(p1,1)=K;p1=p1+1;
f(p1,1)=Lyapunov1(1,:);p1=p1+1;
x=zeros(1,n);y=x;z=x;
end
f;
gama=2.16:0.002:3.18;
x=[gama',f]
[n,m]=size(x);
ave=mean(x);
l1=0;l2=0;
for i=1:n
    l1=l1+(x(i,1)-ave(1,1)).*(x(i,2)-ave(1,2));
    l2=l2+(x(i,1)-ave(1,1)).^2;
end
b=l1./l2
b0=ave(1,2)-b.*ave(1,1)
s1=0;s2=0;
for j=1:n
    s1=s1+(b0+b.*x(j,1)-ave(1,2)).^2;
    s2=s2+(x(j,2)-b0-b.*x(j,1)).^2;
end
s3=s1;s4=s2./(n-2);
%s1,s2,s3,s4
s=s1+s2;
F=s1./s2.*(n-2),n-2