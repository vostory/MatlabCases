p=((4.24-1.24)./0.05+1).*((3.2-0.8)./0.1+1);
f=zeros(p,1);p1=1;
for b=1.24:0.05:4.24
    for gama=0.8:0.1:3.2
Lya1=[];Lya2=[];Lya3=[];
V=eye(3);
S=V;b1=0; 
a=0.4;c=0.2;  %gama=0.8;
h=0.01;
x(1)=0.1;y(1)=0;z(1)=0;n=0;
while z<=200
n=n+1;
k1=h*y(n);
m1=h*(-sin(x(n))-a*y(n)+b*cos(gama*z(n)).*sin(x(n))+c);
k2=h*(y(n)+m1/2);
m2=h*(-sin(x(n)+k1/2)-a*(y(n)+m1/2)+b*cos(gama*(z(n)+h/2)).*sin(x(n)+k1/2)+c);
k3=h*(y(n)+m2/2);
m3=h*(-sin(x(n)+k2/2)-a*(y(n)+m2/2)+b*cos(gama*(z(n)+h/2)).*sin(x(n)+k2/2)+c);
k4=h*(y(n)+m3);
m4=h*(-sin(x(n)+k3)-a*(y(n)+m3)+b*cos(gama*(z(n)+h)).*sin(x(n)+k3)+c);
x(n+1)=x(n)+(k1+2*k2+2*k3+k4)/6;
y(n+1)=y(n)+(m1+2*m2+2*m3+m4)/6;
z(n+1)=n*h;
J = [0 1 0;
b*cos(gama*z(n+1))*cos(x(n+1))-cos(x(n+1)) -a -b*gama*sin(gama*z(n+1))*sin(x(n+1));
0 0 0];
J=eye(3)+h*J;
B=J*V*S;
[V,S,U]=svd(B);
a_max=max(diag(S));
S=(1/a_max)*S;
b1=b1+log(a_max);
Lyapunov1=(log(diag(S))+b1)/(n*h);
end
disp([Lyapunov1]');
K=0;
for i=1:3
    if Lyapunov1(i,1)>0
        K=K+Lyapunov1(i,1);
    end
end
f(p1,1)=K;p1=p1+1;
x=zeros(1,n);y=x;z=x;
    end
end
f
z=zeros(p,2);j=1;
for b=1.24:0.05:4.24
    for gama=0.8:0.1:3.2
        z(j,:)=[b,gama];j=j+1;
    end
end
z
x0=z;y0=f;
[N,m]=size(x0);   %��x0������������
x1=[ones(N,1),x0]; %��������ʽx
A=x1'*x1;B=x1'*y0;   
C=inv(A);
b2=C*B             %��ϵ��b
S0=sum(y0.^2)-sum(y0).^2./N %����ƽ����
s=0;
for i=1:m+1
    s=s+b2(i,1).*B(i,1);
end
S2=sum(y0.^2)-s,N-m-1     %��ʣ��ƽ����
S1=S0-S2,m                 %��ع�ƽ����
F=(S1.*(N-m-1))./(S2.*m)  %��F��
        